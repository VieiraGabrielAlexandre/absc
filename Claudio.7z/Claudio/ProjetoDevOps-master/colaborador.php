<?php
    session_start();
    echo "Usuario: ". $_SESSION['usuarioNome'];    
?>
<br>
<h1>Este sera uma Organização</h1>
<a href="sair.php">Sair</a>